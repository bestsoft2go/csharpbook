using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Menu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            double price = double.Parse(textBoxPrice1.Text);
            double number = (double) numericUpDownNumber1.Value;
            double sum = price * number;
            textBoxSum1.Text = sum.ToString();
        }
    }
}