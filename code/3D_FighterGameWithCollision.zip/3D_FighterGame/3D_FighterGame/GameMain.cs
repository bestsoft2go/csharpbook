﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using System.Diagnostics;

namespace _3D_FighterGame
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class GameMain : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        GameObject launcherBase = new GameObject();
        GameObject launcherHead = new GameObject();
        Model enemyModel = null, missileModel = null;
        List<GameObject> enemies = new List<GameObject>();
        List<GameObject> missiles = new List<GameObject>();
        Camera camera = null;
        Random random = new Random(7);
        SoundEffect explodeSound = null, fireMissileSound = null;
        SpriteFont font = null;
        int score = 0;
//        Fire fire = null;

        GamePadState previousState;
#if !XBOX
        KeyboardState previousKeyboardState;
#endif

        public GameMain()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            camera = new Camera(this);
            this.Components.Add(camera);

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            camera = new Camera(this);

            launcherBase.model = Content.Load<Model>("Models\\launcher_base");
            launcherBase.scale = 0.1f;
            launcherBase.position = new Vector3(0.0f, 0.0f, -10.0f);

            //            launcherHead.model = Content.Load<Model>("Models\\launcher_head");
            //            launcherHead.scale = 0.2f;
            //            launcherHead.position = launcherBase.position + new Vector3(0.0f, 20.0f, -120.0f);

            enemyModel = Content.Load<Model>("Models\\enemy");
            missileModel = Content.Load<Model>("Models\\missile");
            explodeSound = Content.Load<SoundEffect>("Sound\\explosion");
            fireMissileSound = Content.Load<SoundEffect>("Sound\\missilelaunch");
            font = Content.Load<SpriteFont>("SpriteFont");
            //            fire = new Fire(this, Content.Load<Texture2D>("Image\\explosion"));
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        protected void newEnemy()
        {
            GameObject e = new GameObject();
            e.model = enemyModel;
            e.position = new Vector3(random.Next(-5, 5) * 50.0f, random.Next(-5, 5) * 50.0f, -2000.0f);
            e.velocity = new Vector3(0, 0, 2.0f);
            e.scale = 0.03f;
            enemies.Add(e);
        }

        protected void newMissile()
        {
            Matrix rotationMatrix = Matrix.CreateFromYawPitchRoll(camera.Yaw, camera.Pitch, camera.Roll);

            GameObject m = new GameObject();
            m.model = missileModel;
            m.position = launcherBase.position + Vector3.Transform(Vector3.Forward * 10, rotationMatrix);
            m.scale = 10.0f;
            // m.velocity = new Vector3(0, 0, -10.0f);
            m.velocity = Vector3.Transform(Vector3.Forward * 10, rotationMatrix);
            m.rotation = Vector3.Transform(Vector3.Forward, rotationMatrix);
            missiles.Add(m);
            fireMissileSound.Play();
        }

        protected void getLuncherBasePosition()
        {
            Matrix rotationMatrix = Matrix.CreateFromYawPitchRoll(camera.Yaw, camera.Pitch, camera.Roll);
            launcherBase.position = camera.Position + Vector3.Transform(Vector3.Forward * 50, rotationMatrix); //  + Vector3.Down * 10
            launcherBase.rotation.Y = camera.Yaw;
            launcherBase.rotation.X = camera.Pitch;
            launcherBase.rotation.Z = camera.Roll;
            //            Trace.WriteLine(launcherBase.position);
        }

        double lastEnemyDelay = 0.0f;
        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            getLuncherBasePosition();

            KeyboardState keyboardState = Keyboard.GetState();  //得到目前鍵盤每一個按鍵的狀況
            if (keyboardState.IsKeyDown(Keys.Space) && previousKeyboardState.IsKeyUp(Keys.Space))
            {
                newMissile();
            }

            double elapsedTime = gameTime.ElapsedGameTime.TotalSeconds;
            lastEnemyDelay += elapsedTime;
            if (lastEnemyDelay >= 1)
            {
                if (enemies.Count < 10)
                {
                    newEnemy();
                    lastEnemyDelay = 0.0f;
                }
            }

            GameObject[] eList = enemies.ToArray();
            foreach (GameObject e in eList)
            {
                if (e.position.Z >= 0)
                    enemies.Remove(e);
                else
                    e.position += e.velocity;
            }

            GameObject[] mList = missiles.ToArray();
            foreach (GameObject m in mList)
            {
                if (m.position.Z <= -3000)
                    missiles.Remove(m);
                else
                    m.position += m.velocity;
            }

            eList = enemies.ToArray();
            mList = missiles.ToArray();
            foreach (GameObject e in eList)
            {
                foreach (GameObject m in mList) 
                {
                    if (m.boundingSphere().Intersects(e.boundingSphere()))
                    {
                        enemies.Remove(e);
                        score ++;
                        explodeSound.Play();
//                        fire.Play(new Vector2(newState.X, newState.Y), 2);
                    }
                }
            }

            // TODO: Add your update logic here
            camera.Update(gameTime);

            previousKeyboardState = keyboardState;

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin(SpriteBlendMode.AlphaBlend);
            // TODO: Add your drawing code here
            //          DrawGameObject(launcherHead);
            foreach (GameObject e in enemies)
                e.Draw(camera);
            foreach (GameObject m in missiles)
                m.Draw(camera);
            launcherBase.Draw(camera);

            spriteBatch.DrawString(font, String.Format("Score:{0}", score), new Vector2(10, 10), Color.Black);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
