﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace _3D_FighterGame
{
    public class Particle
    {
        public Vector2 Position;    // 位置 *
        public Vector2 Velocity;    // 速度 *
        public Vector2 Acceleration;// 加速度

        public float Lifetime;      // 生命期
        public float Scale;         // 縮放倍數
        private float RotationSpeed; // 旋轉速度

        public float TimeSinceStart; // 目前的年紀     *
        public float Rotation;       // 目前的旋轉角度 *

        public bool Active() // 是否還活著
        {
            return TimeSinceStart < Lifetime; 
        }

        // 初始化
        public void Initialize(Vector2 position, 
                               Vector2 velocity, 
                               Vector2 acceleration,
                               float lifetime, 
                               float scale, 
                               float rotationSpeed)
        {
            this.Position = position;
            this.Velocity = velocity;
            this.Acceleration = acceleration;
            this.Lifetime = lifetime;
            this.Scale = scale;
            this.RotationSpeed = rotationSpeed;

            this.TimeSinceStart = 0.0f; // 剛開始的年紀 為 0

            // 剛開始的旋轉角度  =  亂數 (0 ~ 6.28)
            Random random = new Random();
            this.Rotation = (float)random.NextDouble() * MathHelper.TwoPi; 
        }

        // 更新 速度 位置 旋轉角度 年紀
        public void Update(float t)
        {
            Velocity += Acceleration * t; // 速度 = 速度 + 加速度 X 間隔的時間
            Position += Velocity * t;     // 位置 = 位置 +   速度 X 間隔的時間

            Rotation += RotationSpeed * t; // 旋轉角度 = 旋轉角度 + 旋轉速度 X 間隔的時間

            TimeSinceStart += t; // 目前的年紀 = 目前的年紀 + 間隔的時間
        }
    }
}