﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;

namespace _3D_FighterGame
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class GameComponent_Grid : Microsoft.Xna.Framework.DrawableGameComponent
    {
        public int gridSize = 12; // 每邊有 幾格
        public float gridScale = 1.0f; // 每格 的 寬
        public Color gridColor = new Color(0xFF, 0xFF, 0xFF, 0xFF);   // 格線 的顏色 內定是黑色

        VertexBuffer vertexBuffer; // 頂點緩衝區
        VertexDeclaration vertexDeclaration; // 頂點格式 (每個頂點 包含什麼內容)
        BasicEffect effect; // 產出時會用到的 效果
        int vertexCount;  // 頂點 數目
        GraphicsDevice device; //繪圖設備

        public Matrix world = Matrix.Identity; // 世界 觀測 投影 矩陣

        public Matrix view = Matrix.CreateLookAt(new Vector3(0.0f, 20.0f, 20.0f),
                                                      Vector3.Zero,
                                                      Vector3.Up);

        public Matrix projection = Matrix.CreatePerspectiveFieldOfView(
                                                 MathHelper.ToRadians(45.0f),
                                                 1.333f, 1.0f, 10000.0f);

        public GameComponent_Grid(Game game)
            : base(game)
        {
            // TODO: Construct any child components here
            this.device = game.GraphicsDevice;
        }

        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            // TODO: Add your initialization code here
            effect = new BasicEffect(device, null); // 效果

            vertexCount = (gridSize + 1) * 4; // 每邊的頂點數 比 每邊的格數 多一，共有四個邊

            // 每個頂點 包含 位置 和 顏色 ，先空出 vertexCount 個 頂點
            VertexPositionColor[] vertices = new VertexPositionColor[vertexCount];

            float length = (float)gridSize * gridScale; // 邊長 等於 格數 乘以 格寬
            float halfLength = length * 0.5f;  // 半邊長 因為是要 以原點為中心 左右 各半

            int index = 0; // 頂點 索引

            // 定義頂點位置  頂都是 躺在 X Z 平面上
            for (int i = 0; i <= gridSize; ++i)
            {
                vertices[index++] = new VertexPositionColor(
                    new Vector3(-halfLength, 0.0f, i * gridScale - halfLength),
                    gridColor); // 左邊的頂點

                vertices[index++] = new VertexPositionColor(
                    new Vector3(halfLength, 0.0f, i * gridScale - halfLength),
                    gridColor); // 右邊的頂點

                vertices[index++] = new VertexPositionColor(
                    new Vector3(i * gridScale - halfLength, 0.0f, -halfLength),
                    gridColor); // 上緣的頂點

                vertices[index++] = new VertexPositionColor(
                    new Vector3(i * gridScale - halfLength, 0.0f, halfLength),
                    gridColor); // 下緣的頂點
            }

            // 建立 頂點緩衝區
            vertexBuffer = new VertexBuffer(device, vertexCount *  VertexPositionColor.SizeInBytes,
                                             BufferUsage.WriteOnly);
            // 將 頂點資料 複製入 頂點緩衝區 內
            vertexBuffer.SetData<VertexPositionColor>(vertices);

            // 頂點格式
            vertexDeclaration = new VertexDeclaration(device, VertexPositionColor.VertexElements);

            base.Initialize();
        }

        /// <summary>
        /// Allows the game component to update itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            // TODO: Add your update code here

            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            
            // 效果 三大矩陣 設定
//            effect.World = world;
//            effect.View = view;
//            effect.Projection = projection;

            effect.VertexColorEnabled = true;  // 使用 頂點顏色 效果

            device.VertexDeclaration = vertexDeclaration; // 頂點格式
            device.Vertices[0].SetSource(vertexBuffer, 0, VertexPositionColor.SizeInBytes); // 頂點來源

            effect.Begin(); // 效果 開始

            foreach (EffectPass CurrentPass in effect.CurrentTechnique.Passes)
            {
                CurrentPass.Begin();
                device.DrawPrimitives(PrimitiveType.LineList, 0, vertexCount / 2); // 兩兩畫線 所以只有 vertexCount/2 條線
                CurrentPass.End();
            }
            effect.End();
        }
    }
}