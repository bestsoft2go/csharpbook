﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Diagnostics;

namespace BallGame
{
    class Sprite
    {
        public Texture2D texture;  // 2D 紋理圖
        public Vector2 position;   // 2D 紋理圖 的位置
        public Vector2 velocity = Vector2.Zero;   // 2D 紋理圖 的位移速度
        public Vector2 size;
        public bool isAlive = false;

        public Sprite(Texture2D texture, Vector2 position)
        {
            this.texture = texture;
            this.position = position;
            this.size.X = texture.Width;
            this.size.Y = texture.Height;
        }

        public bool isInside(Vector2 screenSize)
        {
            // 右緣 碰到 視窗右邊了
            if (position.X + texture.Width + velocity.X > screenSize.X)
                return false;

            // 下緣 碰到 視窗底邊了
            if (position.Y + texture.Height + velocity.Y > screenSize.Y)
                return false;

            // 左緣 碰到 視窗左邊了
            if (position.X + velocity.X < 0)
                return false;

            // 上緣 碰到 視窗上邊了
            if (position.Y + velocity.Y < 0)
                return false;
            return true;
        }

        // 移動
        public void Move(Vector2 screenSize)
        {
            // 右緣 碰到 視窗右邊了
            if (position.X + size.X + velocity.X > screenSize.X)
                velocity.X = -velocity.X;

            // 下緣 碰到 視窗底邊了
            if (position.Y + size.Y + velocity.Y > screenSize.Y)
                velocity.Y = -velocity.Y;

            // 左緣 碰到 視窗左邊了
            if (position.X + velocity.X < 0)
                velocity.X = -velocity.X;

            // 上緣 碰到 視窗上邊了
            if (position.Y + velocity.Y < 0)
                velocity.Y = -velocity.Y;

            position += velocity;
        }

        public virtual void draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, position, Color.White);
        }

    }

    class Animation : Sprite
    {
        public int rows, cols;
        public int cellWidth, cellHeight;
        public int[,] cells;
        public int cellIdx;
        public bool isEnd = false;

        public Animation(Texture2D texture, Vector2 position, int rows, int cols, int[,] cells)
            : base(texture, position)
        {
            this.rows = rows;
            this.cols = cols;
            this.cells = cells;
            cellWidth = texture.Width / rows;
            cellHeight = texture.Height / cols;
            cellIdx = 0;
        }

        int counter = 0;
        public void update()
        {
            counter = counter + 1;
            if (counter == 3)
            {
                cellIdx++;
                counter = 0;
                if (cellIdx == cells.GetLength(0))
                {
                    isEnd = true;
                }
            }
        }

        public override void draw(SpriteBatch spriteBatch)
        {
            Rectangle d = new Rectangle((int)position.X, (int)position.Y, (int) (size.X/cols), (int) (size.Y/rows));
            Rectangle s = new Rectangle(cells[cellIdx,0] * cellWidth, cells[cellIdx,1] * cellHeight, cellWidth, cellHeight);
            spriteBatch.Draw(texture, d, s, Color.White);
            Trace.WriteLine("cells[cellIdx,0]=" + cells[cellIdx, 0] + " cells[cellIdx,1]=" + cells[cellIdx, 1]);
        }
    }
}
