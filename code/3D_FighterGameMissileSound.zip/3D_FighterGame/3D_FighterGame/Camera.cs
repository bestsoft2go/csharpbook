﻿using Microsoft.Xna.Framework;  // 因為用到 Matrix、Vector3
using Microsoft.Xna.Framework.Graphics; // 因為用到 GraphicsDeviceManager、Viewport
using Microsoft.Xna.Framework.Input; // 因為用到 KeyboardState

namespace _3D_FighterGame
{
    class Camera : Microsoft.Xna.Framework.GameComponent
    {
        public Matrix view;         //  視覺矩陣
        public Matrix projection =        //  投影矩陣
                 Matrix.CreatePerspectiveFieldOfView(    
                                  MathHelper.PiOver4,  // 視角 45度
                                  1.333f, // 螢幕 寬高比
                                  1,      // 最近的Z軸截點
                                  10000);  // 最遠的Z軸截點 

        public Vector3 FrontVector = new Vector3(0, 0, -1); //相機的 往前向量
        public Vector3 Position = new Vector3(0.0f, 2.0f, 20.0f); // 相機的位置
        public float Yaw = 0.0f, Pitch = 0.0f, Roll = 0.0f;
        public float YawDelta = 0.2f, PitchDelta = 0.2f, RollDelta = 0.2f;
        public float MoveDelta = 200;   // 前後走 的 增減量

        public Camera(Game game)
            : base(game)
        {
            // TODO: Construct any child components here

        }

        //更新 相機 的位置
        public void UpdateCamera(Vector3 Position, float Yaw, float Pitch, float Roll)
        {
            //攝影機一開始是 朝向 負 Z 軸 看著(0, 0, -1) 的 
            Vector3 LookAt = Position + Vector3.TransformNormal(FrontVector,
                                            Matrix.CreateFromYawPitchRoll(Yaw, Pitch, Roll)); // 向量 X 矩陣 ==> 向量  (假設 w 值 = 0)

            // 根據 相機的位置 相機要看到的點 相機上方的向量 得到 視覺矩陣
            view = Matrix.CreateLookAt(Position,  // 相機的位置
                                       LookAt,    // 相機要看到的點
                                       Vector3.Up); // 相機上方的向量
        }

        public override void Initialize()
        {
            base.Initialize();
        }

        public override void Update(GameTime gameTime)
        {
            // TODO: Add your update code here
            float elapsedTime = (float) gameTime.ElapsedGameTime.TotalSeconds;

            KeyboardState newState;  // 宣告一個KeyboardState 結構的變數
            newState = Keyboard.GetState();  //得到目前鍵盤每一個按鍵的狀況
            if (newState.IsKeyDown(Keys.Right)) Yaw -= YawDelta * elapsedTime;  //判斷Right鍵是否已經被按下
            if (newState.IsKeyDown(Keys.Left)) Yaw += YawDelta * elapsedTime;  //判斷Left鍵是否已經被按下
            if (newState.IsKeyDown(Keys.Up)) Pitch += PitchDelta * elapsedTime;
            if (newState.IsKeyDown(Keys.Down)) Pitch -= PitchDelta * elapsedTime;
/*
            if (newState.IsKeyDown(Keys.F))   //判斷Up鍵是否已經被按下
            {
                Position += Vector3.Transform(MoveDelta * elapsedTime * FrontVector,
                                  Matrix.CreateRotationY(Yaw));
            }

            if (newState.IsKeyDown(Keys.B))  //判斷Down鍵是否已經被按下
            {
                Position += Vector3.Transform(-MoveDelta * elapsedTime * FrontVector,
                                  Matrix.CreateRotationY(Yaw));
            }
*/
            UpdateCamera(Position, Yaw, Pitch, Roll);

            base.Update(gameTime);
        }
    }
}
