using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Menu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            listBoxOrders.Items.Add("�~�W\t���\t�ƶq\t�p�p");
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            double sum = 0.0;
            for (int i = 1; i < listBoxOrders.Items.Count; i++)
            {
                String[] tokens = listBoxOrders.Items[i].ToString().Split('\t');
                double tsum = double.Parse(tokens[3]);
                sum += tsum;
            }
            textBoxSum.Text = sum.ToString();
        }

        private void listBoxItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            String itemLine = listBoxItems.Items[listBoxItems.SelectedIndex].ToString();
            String[] tokens = itemLine.Split(',');
            buttonName1.Text = tokens[0];
            textBoxPrice1.Text = tokens[1];
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            String name = buttonName1.Text;
            double price = double.Parse(textBoxPrice1.Text);
            double number = (double)numericUpDownNumber1.Value;
            double sum = price * number;
            textBoxSum1.Text = sum.ToString();
            listBoxOrders.Items.Add(name + "\t" + price + "\t" + number + "\t" + sum);
        }
    }
}