using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Menu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            DataGridViewRowCollection rows = dataGridViewMenu.Rows;
            rows.Add(new Object[] { "����", 25 });
            rows.Add(new Object[] { "���", 25 });
            rows.Add(new Object[] { "����", 30 });
            rows.Add(new Object[] { "�ï]����", 35 });
        }

        private void calculate()
        {
            double sum = 0.0;
            for (int i = 0; i < dataGridViewOrder.Rows.Count; i++)
            {
                DataGridViewRow row = dataGridViewOrder.Rows[i];
                if (row.Cells[i].Value != null)
                    sum += (double) row.Cells[3].Value;
            }
            textBoxSum.Text = sum.ToString();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            String name = buttonName1.Text;
            double price = double.Parse(textBoxPrice1.Text);
            double number = (double)numericUpDownNumber1.Value;
            double sum = price * number;
            textBoxSum1.Text = sum.ToString();
            dataGridViewOrder.Rows.Add(new Object[] { name, price, number, sum });
            calculate();
        }

        private void dataGridViewMenu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            buttonName1.Text = dataGridViewMenu.Rows[e.RowIndex].Cells[0].Value.ToString();
            textBoxPrice1.Text = dataGridViewMenu.Rows[e.RowIndex].Cells[1].Value.ToString();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            calculate();
        }
    }
}