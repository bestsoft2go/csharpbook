﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace _3D_FighterGame
{
    public class Fire : Microsoft.Xna.Framework.DrawableGameComponent
    {
        private Texture2D texture; // 紋理圖
        private Vector2 origin; // 紋理圖中心點座標

        public int maxNumParticles_Times = 2; // 最多要呈現幾次 (要先空出幾倍的粒子數)
        
        Particle[] particles; // 粒子陣列
        Queue<Particle> freeParticles; // 用來記錄 粒子陣列 中 可使用的粒子
        // freeParticles.Count  可使用的粒子數目

        protected int minNumParticles; // 每次呈現 可能使用最少 的粒子數目
        protected int maxNumParticles; // 每次呈現 可能使用最多 的粒子數目
       
        protected float minInitialSpeed;  // 每個粒子 的可能 最小 速度
        protected float maxInitialSpeed;  // 每個粒子 的可能 最大 速度

        protected float minAcceleration; // 每個粒子 的可能 最小 加速度
        protected float maxAcceleration; // 每個粒子 的可能 最大 加速度

        protected float minRotationSpeed; // 每個粒子 的可能 最小 旋轉速度
        protected float maxRotationSpeed; // 每個粒子 的可能 最大 旋轉速度

        protected float minLifetime; // 每個粒子 的可能 最小 生命期
        protected float maxLifetime; // 每個粒子 的可能 最大 生命期

        protected float minScale; // 每個粒子 的可能 最小 倍數
        protected float maxScale; // 每個粒子 的可能 最大 倍數

        SpriteBatch spriteBatch;
        const float TimeBetweenAddParticles = .5f; // 每隔幾秒 呈現一次
        float timeTillAddParticles = 0.0f; // 還差幾秒 就該呈現
        float Duration = 0;  // 呈現的總秒數
        Vector2 Position = Vector2.Zero; // 呈現 的位置
        Random random = new Random(); // 亂數

        // 建構元
        public Fire(Game game, Texture2D texture) : base(game)
        {            
            this.texture = texture;
            origin.X = texture.Width / 2;
            origin.Y = texture.Height / 2;
            
        }

        // 初始化
        public override void Initialize()
        {
            InitializeConstants();

            // 粒子陣列 -- 呈現幾次 X 每次呈現可能使用最多的粒子數目
            particles = new Particle[maxNumParticles_Times * maxNumParticles];
            freeParticles = new Queue<Particle>();

            for (int i = 0; i < particles.Length; i++)
            {
                particles[i] = new Particle();  // 產生每一個粒子物件
                freeParticles.Enqueue(particles[i]); // 將此粒子物件放入可用粒子名單
            }
            base.Initialize();
        }


        private void InitializeConstants()
        {
            minNumParticles = 20; // 每次呈現 可能使用最少 的粒子數目
            maxNumParticles = 25; // 每次呈現 可能使用最多 的粒子數目
       
            minInitialSpeed = 40;  // 每個粒子 的可能 最小 速度
            maxInitialSpeed = 500;  // 每個粒子 的可能 最大 速度

            minAcceleration = 0; // 每個粒子 的可能 最小 加速度
            maxAcceleration = 0; // 每個粒子 的可能 最大 加速度

            minRotationSpeed = -MathHelper.PiOver4; // 每個粒子 的可能 最小 旋轉速度
            maxRotationSpeed =  MathHelper.PiOver4; // 每個粒子 的可能 最大 旋轉速度

            minLifetime = 0.5f; // 每個粒子 的可能 最小 生命期
            maxLifetime = 1.0f; // 每個粒子 的可能 最大 生命期

            minScale = 0.3f; // 每個粒子 的可能 最小 倍數
            maxScale = 1.0f; // 每個粒子 的可能 最大 倍數
        }

        public void Play(Vector2 position, float duration)
        {
            this.Duration = duration;
            timeTillAddParticles = 0.0f;
            this.Position = position;
        }

        private void AddParticles(Vector2 position)
        {
            // 這次使用的粒子數目
            int numParticles = random.Next(minNumParticles, maxNumParticles);

            // 從 可用粒子名單 儘量取出粒子 
            for (int i = 0; i < numParticles && freeParticles.Count > 0; i++)
            {
                // 初始化每個粒子
                Particle p = freeParticles.Dequeue();
                InitializeParticle(p, position);               
            }
        }
        
        // 初始化每個粒子
        private void InitializeParticle(Particle p, Vector2 position)
        {
            float angle = (float)random.NextDouble() * MathHelper.TwoPi;
            Vector2 direction = new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle));

            float velocity = minInitialSpeed + (float)random.NextDouble() * (maxInitialSpeed - minInitialSpeed);
            //float acceleration = minAcceleration + (float)random.NextDouble() * (maxAcceleration - minAcceleration);

            float lifetime = minLifetime + (float)random.NextDouble() * (maxLifetime - minLifetime);
            float scale = minScale + (float)random.NextDouble() * (maxScale - minScale);
            float rotationSpeed = minRotationSpeed + (float)random.NextDouble() * (maxRotationSpeed - minRotationSpeed);

            float acceleration = -velocity / lifetime;

            p.Initialize(
                position, velocity * direction, acceleration * direction,
                lifetime, scale, rotationSpeed);
        }

        
        public override void Update(GameTime gameTime)
        {
            float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (Duration > 0)
            {
              Duration -= dt;

              timeTillAddParticles -= dt;
              if (timeTillAddParticles < 0)
              {
                AddParticles(this.Position);
                timeTillAddParticles = TimeBetweenAddParticles;
              }
            }

            // 可使用的粒子數目 < 總粒子數目 (就是還有粒子需要更新)
            if (freeParticles.Count < particles.Length)
            {
                foreach (Particle p in particles)
                {
                    if (p.Active())
                    {
                        p.Update(dt);
                        if (!p.Active()) freeParticles.Enqueue(p);
                    }
                }
            }

            base.Update(gameTime);
        }


        public override void Draw(GameTime gameTime)
        {
            spriteBatch = (SpriteBatch)Game.Services.GetService(typeof(SpriteBatch));
            spriteBatch.Begin(SpriteBlendMode.Additive); // 加
            
            foreach (Particle p in particles)
            {
                // 在粒子陣列 的 每一個 粒子
                if (!p.Active())
                    continue;

                float ratio = p.TimeSinceStart / p.Lifetime;

                float alpha = 4 * ratio * (1 - ratio);
                Color color = new Color(new Vector4(1, 1, 1, alpha));

                float scale = p.Scale * (.75f + .25f * ratio);

                spriteBatch.Draw(texture, p.Position, null, color,
                    p.Rotation, origin, scale, SpriteEffects.None, 0.0f);
            }

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}

