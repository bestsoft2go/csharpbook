﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonPrev_Click(object sender, EventArgs e)
        {
            webBrowser.GoBack();
        }

        private void buttonNext_Click(object sender, EventArgs e)
        {
            webBrowser.GoForward();
        }

        private void updateState()
        {
            buttonPrev.Enabled = webBrowser.CanGoBack;
            buttonNext.Enabled = webBrowser.CanGoForward;
            if (webBrowser.Url != null)
                comboBoxUrl.Text = webBrowser.Url.ToString();
        }

        private void buttonGo_Click(object sender, EventArgs e)
        {
            webBrowser.Navigate(comboBoxUrl.Text);
        }

        private void webBrowser_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            updateState();
        }
    }
}
